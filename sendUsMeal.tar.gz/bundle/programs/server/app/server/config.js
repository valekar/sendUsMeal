(function(){MailOptions = {
    apiKey: 'key-6593e466d40dc70289c5bc4f4adb3794',
    domain: 'mybitefood.in'
};


process.env['MAIL_FROM'] = "no-reply@MyBiteFood.in";

Kadira.connect('gN4MBAvDg9LdYX2WC', 'ee5acb89-fd2e-4b20-9f09-598f52d63827');

})();
