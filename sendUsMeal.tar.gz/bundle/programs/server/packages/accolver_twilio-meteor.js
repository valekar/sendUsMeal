(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var Twilio;

(function () {

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/accolver:twilio-meteor/accolver:twilio-meteor.js         //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
Twilio = Npm.require('twilio');                                      // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['accolver:twilio-meteor'] = {
  Twilio: Twilio
};

})();

//# sourceMappingURL=accolver_twilio-meteor.js.map
