(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var Mailgun;

(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/gfk:mailgun-api/mailgun-api.js                                                                           //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
Mailgun = (function () {                                                                                             // 1
    'use strict';                                                                                                    // 2
                                                                                                                     // 3
    /***                                                                                                             // 4
     * Constructs a new instance of the mailgun wrapper                                                              // 5
     * @param {Object} options                                                                                       // 6
     * @param {String} options.apiKey The api key to use in communication with mailgun                               // 7
     * @param {String} options.domain The domain to use in communication with mailgun                                // 8
     * @param {Boolean} options.mute Set to true if you wish to mute the console error logs in validateWebhook() function
     * @param {String} options.proxy - The proxy URI in format http[s]://[auth@]host:port. ex: 'http://proxy.example.com:8080'
     * @constructor                                                                                                  // 11
     */                                                                                                              // 12
    var constructor = function (options) {                                                                           // 13
        var mailgunJS = Npm.require('mailgun-js');                                                                   // 14
        this.api = new mailgunJS(options);                                                                           // 15
    };                                                                                                               // 16
                                                                                                                     // 17
    /***                                                                                                             // 18
     * Sends the email to mailgun                                                                                    // 19
     *                                                                                                               // 20
     * @param {Object} emailObject                                                                                   // 21
     * @param {String} [emailObject.to] Address to which to sent the email                                           // 22
     * @param {String} [emailObject.cc] Address to which to cc the email                                             // 23
     * @param {String} [emailObject.bcc] Address to which to bcc the email                                           // 24
     * @param {String} [emailObject.html] The html version of the email                                              // 25
     * @param {String} [emailObject.text] The text version of the email                                              // 26
     * @param {String} [emailObject.subject] the subject of the email                                                // 27
     * @param {Array} [emailObject.tags] Tags to sent to mailgun                                                     // 28
     * @param {Object} options [options={}] The options to use for sending the email                                 // 29
     * @param {String} [options.testmode] Adds mailgun testmode parameter                                            // 30
     * @param {String} [options.saveEmailTo] Specifies the location to save a copy of the html email to. Tries to create the directories if they don't exist yet
     * @returns {Object} result                                                                                      // 32
     * @returns {Object} result.error Object containing the error given during the sending of the mail               // 33
     * @returns {String} result.response response returned by email provider wrapper                                 // 34
     */                                                                                                              // 35
    constructor.prototype.send = function (emailObject, options) {                                                   // 36
        var Future = Npm.require('fibers/future'),                                                                   // 37
            fs = Npm.require('fs'),                                                                                  // 38
            mkdirpModule = Npm.require('mkdirp'),                                                                    // 39
            writeFile = Future.wrap(fs.writeFile),                                                                   // 40
            mkdirp = Future.wrap(mkdirpModule.mkdirp, 1),                                                            // 41
            errors = [], result;                                                                                     // 42
                                                                                                                     // 43
        options = options || {};                                                                                     // 44
                                                                                                                     // 45
        if(options.testmode) {                                                                                       // 46
            emailObject['o:testmode'] = true;                                                                        // 47
        }                                                                                                            // 48
                                                                                                                     // 49
        if (options.saveEmailTo) {                                                                                   // 50
            var targetDir = options.saveEmailTo.split('/');                                                          // 51
            targetDir.pop();                                                                                         // 52
            targetDir = targetDir.join('/');                                                                         // 53
                                                                                                                     // 54
            var mkdirResult = mkdirp(targetDir).wait();                                                              // 55
                                                                                                                     // 56
            if (mkdirResult === null) {                                                                              // 57
                writeFile(options.saveEmailTo , emailObject.html).wait();                                            // 58
            } else {                                                                                                 // 59
                errors.push('Error creating directories! Errorcode: ' + mkdirResult.code + ' path: ' + mkdirResult.path);
            }                                                                                                        // 61
        }                                                                                                            // 62
                                                                                                                     // 63
        if(emailObject.tags) {                                                                                       // 64
            emailObject['o:tag'] = _.clone(emailObject.tags);                                                        // 65
            delete emailObject.tags;                                                                                 // 66
        }                                                                                                            // 67
                                                                                                                     // 68
        if (errors.length) {                                                                                         // 69
            result = {                                                                                               // 70
                error: errors.join(',')                                                                              // 71
            };                                                                                                       // 72
        } else {                                                                                                     // 73
            result = this._send(emailObject).wait();                                                                 // 74
        }                                                                                                            // 75
                                                                                                                     // 76
        return result;                                                                                               // 77
    };                                                                                                               // 78
                                                                                                                     // 79
    constructor.prototype._send = function (emailObject) {                                                           // 80
        var Future = Npm.require('fibers/future'),                                                                   // 81
            fut = new Future();                                                                                      // 82
                                                                                                                     // 83
        this.api.messages().send(emailObject, function (error, response) {                                           // 84
            response = response || {};                                                                               // 85
            fut.return({error: error, response: response});                                                          // 86
        });                                                                                                          // 87
                                                                                                                     // 88
        return fut;                                                                                                  // 89
    };                                                                                                               // 90
                                                                                                                     // 91
    /***                                                                                                             // 92
     * Checks if a key exists if so replaces the value with a string valued 'yes' or 'no'                            // 93
     *                                                                                                               // 94
     * @param {Object} obj The object that holds the keys to convert                                                 // 95
     * @param {Array|String} keys the key(s) to convert to a value mailgun understands                               // 96
     * @private                                                                                                      // 97
     */                                                                                                              // 98
    constructor.prototype._convertBooleans = function (obj, keys) {                                                  // 99
        var value;                                                                                                   // 100
        keys = _.isArray(keys) ? keys : [keys];                                                                      // 101
                                                                                                                     // 102
                                                                                                                     // 103
        _.each(keys, function (key) {                                                                                // 104
            value = obj[key];                                                                                        // 105
                                                                                                                     // 106
            if (!_.isUndefined(value)) {                                                                             // 107
                if (_.isBoolean(value)) {                                                                            // 108
                    value = value ? 'yes' : 'no';                                                                    // 109
                } else if (_.isString(value)) {                                                                      // 110
                    value = value === 'no' ? 'no' : 'yes';                                                           // 111
                } else {                                                                                             // 112
                    value = !!value;                                                                                 // 113
                }                                                                                                    // 114
                obj[key] = value;                                                                                    // 115
            }                                                                                                        // 116
        });                                                                                                          // 117
    };                                                                                                               // 118
    /***                                                                                                             // 119
     * Converts a date string or date object to a RFC2822 timestring                                                 // 120
     * @param {Date|String} date the date to convert to a RFC2822 timestring                                         // 121
     * @returns {String} The RFC2822 Timestring                                                                      // 122
     * @private                                                                                                      // 123
     */                                                                                                              // 124
    constructor.prototype._convertDateToTimeString = function (date) {                                               // 125
        date = date instanceof Date ? date : new Date(date);                                                         // 126
        return (date / 1000).toString();                                                                             // 127
    };                                                                                                               // 128
                                                                                                                     // 129
    /***                                                                                                             // 130
     * Converts RFC2822 Timestring to a Date object                                                                  // 131
     * @param {String} timestring the RFC2822 timestring as returned by mailgun                                      // 132
     * @returns {Date} The date object                                                                               // 133
     * @private                                                                                                      // 134
     */                                                                                                              // 135
    constructor.prototype._convertTimeStringToDate = function (timestring) {                                         // 136
        return new Date(timestring * 1000);                                                                          // 137
    };                                                                                                               // 138
                                                                                                                     // 139
                                                                                                                     // 140
    /***                                                                                                             // 141
     * Checks events for the given filter.                                                                           // 142
     * @param {Object} filter [filter={}] The filter to use for retrieving the events see: http://documentation.mailgun.com/api-events.html#filter-field
     * @param {Date|String} [filter.beginDate] The beginning of the time range to select log records from. By default it is the time of the request
     * @param {Date|String} [filter.endDate] The end of the time range and the direction of the log record traversal. If end is less than begin, then traversal is performed in the timestamp descending order, otherwise in timestamp ascending order. By default, if ascending is yes, then it is a date in the distant future, otherwise a date in the distant past.
     * @param {Boolean} [filter.ascending=false] The direction of log record traversal. If end is also specified, then the relation between begin and end should agree with the ascending value, otherwise an error will be returned. The default value is deduced from the begin and end relation. If end is not specified, then the value is no, effectively defining traversal direction from begin, to the past, until the end of time.
     * @param {Boolean} [filter.pretty=true] Defaults to true on the server                                          // 147
     * @returns {Future}                                                                                             // 148
     */                                                                                                              // 149
    constructor.prototype.getEvents = function (filter) {                                                            // 150
        var Future = Npm.require('fibers/future'),                                                                   // 151
            fut = new Future(),                                                                                      // 152
            self = this;                                                                                             // 153
        filter = filter || {};                                                                                       // 154
                                                                                                                     // 155
        if (filter.beginDate) {                                                                                      // 156
            filter.begin = this._convertDateToTimeString(filter.beginDate);                                          // 157
            delete filter.beginDate;                                                                                 // 158
        }                                                                                                            // 159
                                                                                                                     // 160
        if (filter.endDate) {                                                                                        // 161
            filter.end = this._convertDateToTimeString(filter.endDate);                                              // 162
            delete filter.endDate;                                                                                   // 163
        }                                                                                                            // 164
                                                                                                                     // 165
        this._convertBooleans(filter, ['ascending', 'pretty']);                                                      // 166
                                                                                                                     // 167
        this.api.events().get(filter, function (error, response) {                                                   // 168
            response = response || {};                                                                               // 169
            var items = response.items || [];                                                                        // 170
            _.each(response.items, function (item) {                                                                 // 171
                item.date = self._convertTimeStringToDate(item.timestamp);                                           // 172
            });                                                                                                      // 173
            fut.return({error: error, items: items});                                                                // 174
        });                                                                                                          // 175
                                                                                                                     // 176
        return fut;                                                                                                  // 177
    };                                                                                                               // 178
	/***                                                                                                                // 179
	 * Iterates over the events found with the given filter and calls the appropiate handler for each event.            // 180
	 * @param {Object} filter [filter={}] The filter to use for retrieving the events see: http://documentation.mailgun.com/api-events.html#filter-field
	 * @param {Object} eventHandlers hold handlers for the different eventtypes                                         // 182
	 * @param {Function} eventHandlers.before [eventHandlers.before] Handler to be executed on all events before the actual handler is executed
	 * @param {Function} eventHandlers.accepted [eventHandlers.accepted] Handler executed on accepted event             // 184
	 * @param {Function} eventHandlers.rejected [eventHandlers.rejected] Handler executed on rejected event             // 185
	 * @param {Function} eventHandlers.delivered [eventHandlers.delivered] Handler executed on delivered event          // 186
	 * @param {Function} eventHandlers.failed [eventHandlers.failed] Handler executed on failed event                   // 187
	 * @param {Function} eventHandlers.openend [eventHandlers.openend] Handler executed on openend event                // 188
	 * @param {Function} eventHandlers.clicked [eventHandlers.clicked] Handler executed on clicked event                // 189
	 * @param {Function} eventHandlers.unsubscribed [eventHandlers.unsubscribed] Handler executed on unsubscribed event // 190
	 * @param {Function} eventHandlers.complained [eventHandlers.complained] Handler executed on complained event       // 191
	 * @param {Function} eventHandlers.stored [eventHandlers.stored] Handler executed on stored event                   // 192
	 *                                                                                                                  // 193
	 * @returns {{}}                                                                                                    // 194
	 */                                                                                                                 // 195
	constructor.prototype.handleEvents = function (filter, eventHandlers) {                                             // 196
		var result = {};                                                                                                   // 197
                                                                                                                     // 198
		if (!_.isObject(eventHandlers)) {                                                                                  // 199
			result.error = new Error('The eventHandlers argument is not a object');                                           // 200
		}                                                                                                                  // 201
                                                                                                                     // 202
		var events = this.getEvents(filter).wait(),                                                                        // 203
			supportedEventTypes = _.values(this.CONST.EVENTTYPES);                                                            // 204
                                                                                                                     // 205
		if (events.error) {                                                                                                // 206
			result.error = events.error;                                                                                      // 207
		} else {                                                                                                           // 208
			_.each(events.items, function (item) {                                                                            // 209
				if (_.isFunction(eventHandlers.before)) {                                                                        // 210
					eventHandlers.before(item);                                                                                     // 211
				}                                                                                                                // 212
                                                                                                                     // 213
				if (_.isFunction(eventHandlers[item.event])) {                                                                   // 214
					eventHandlers[item.event](item);                                                                                // 215
				}                                                                                                                // 216
			}, this);                                                                                                         // 217
		}                                                                                                                  // 218
                                                                                                                     // 219
		return result;                                                                                                     // 220
	};                                                                                                                  // 221
                                                                                                                     // 222
                                                                                                                     // 223
    constructor.prototype.CONST = {                                                                                  // 224
        EVENTTYPES: {                                                                                                // 225
            ACCEPTED: 'accepted',                                                                                    // 226
            REJECTED: 'rejected',                                                                                    // 227
            DELIVERED: 'delivered',                                                                                  // 228
            FAILED: 'failed',                                                                                        // 229
            OPENED: 'openend',                                                                                       // 230
            CLICKED: 'clicked',                                                                                      // 231
            UNSUBSCRIBED: 'unsubscribed',                                                                            // 232
            COMPLAINED: 'complained',                                                                                // 233
            STORED: 'stored'                                                                                         // 234
        },                                                                                                           // 235
		REASONS: {                                                                                                         // 236
			BOUNCE: 'bounce'                                                                                                  // 237
		},                                                                                                                 // 238
		SEVERITIES: {                                                                                                      // 239
			PERMANENT: 'permanent',                                                                                           // 240
			TEMPORARY: 'temporary'                                                                                            // 241
		}                                                                                                                  // 242
    };                                                                                                               // 243
                                                                                                                     // 244
    return constructor;                                                                                              // 245
}());                                                                                                                // 246
                                                                                                                     // 247
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['gfk:mailgun-api'] = {
  Mailgun: Mailgun
};

})();

//# sourceMappingURL=gfk_mailgun-api.js.map
