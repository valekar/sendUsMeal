(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['kevohagan:sweetalert'] = {};

})();

//# sourceMappingURL=kevohagan_sweetalert.js.map
